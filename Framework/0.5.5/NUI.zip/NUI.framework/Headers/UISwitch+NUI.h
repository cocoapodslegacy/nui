//
//  UISwitch+NUI.h
//  NUIDemo
//
//  Created by Benjamin Clayton @benclayton on 04/01/2013.
//  Copyright (c) 2013 Benjamin Clayton @benclayton. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "NUIRenderer.h"

@interface UISwitch (NUI)

@end
